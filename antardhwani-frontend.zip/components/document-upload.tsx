"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, CheckCircle, AlertCircle, Download, Info } from "lucide-react"

const SCHEMES = {
  "pm-kisan": {
    name: "Pradhan Mantri Kisan Samman Nidhi (PM-Kisan)",
    required_documents: ["Aadhaar Card", "Bank Passbook/Statement", "Land Records (Khasra/Khatauni)"],
  },
  kcc: {
    name: "Kisan Credit Card (KCC)",
    required_documents: ["Aadhaar Card", "PAN Card", "Bank Passbook", "Land Records"],
  },
  ridf: {
    name: "Rural Infrastructure Development Fund (RIDF)",
    required_documents: ["Project Proposal", "Land Documents", "Aadhaar Card", "Bank Passbook"],
  },
}

export default function DocumentUpload() {
  const [personalDocs, setPersonalDocs] = useState<File[]>([])
  const [formTemplate, setFormTemplate] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string>("")

  const handlePersonalDocsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPersonalDocs(Array.from(e.target.files))
    }
  }

  const handleFormTemplateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormTemplate(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (personalDocs.length === 0) {
      setError("Please upload your personal documents")
      return
    }

    setUploading(true)
    setProgress(0)
    setError("")

    try {
      const formData = new FormData()
      personalDocs.forEach((file) => {
        formData.append("documents", file)
      })

      if (formTemplate) {
        formData.append("form_template", formTemplate)
      }

      setProgress(30)
      const ingestResponse = await fetch("/api/ingest", {
        method: "POST",
        body: formData,
      })

      if (!ingestResponse.ok) {
        throw new Error("Failed to upload documents")
      }

      const ingestResult = await ingestResponse.json()
      setProgress(60)

      const fillResponse = await fetch("/api/auto_fill_user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: ingestResult.user_id,
          output_type: "pdf",
          auto_detect_schemes: true,
        }),
      })

      if (!fillResponse.ok) {
        throw new Error("Failed to process documents")
      }

      const fillResult = await fillResponse.json()
      setProgress(100)
      setResult(fillResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-primary" />
            <span>Smart Form Filling</span>
          </CardTitle>
          <CardDescription>
            Upload your documents and we'll automatically detect eligible schemes and fill forms for you
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Upload your personal documents (Aadhaar, land records, bank passbook, PAN card, income certificate, etc.)
              and optionally a blank form you need filled. Our AI will detect what schemes you're eligible for and fill
              the forms automatically.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <Label htmlFor="personal-docs">Upload Your Documents</Label>
            <Input
              id="personal-docs"
              type="file"
              multiple
              accept=".pdf,.png,.jpg,.jpeg,.docx"
              onChange={handlePersonalDocsChange}
              className="cursor-pointer"
            />
            <p className="text-sm text-muted-foreground">
              Upload Aadhaar card, land records, bank passbook, PAN card, income certificate, etc.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="form-template">Upload Blank Form (Optional)</Label>
            <Input
              id="form-template"
              type="file"
              accept=".pdf,.png,.jpg,.jpeg"
              onChange={handleFormTemplateChange}
              className="cursor-pointer"
            />
            <p className="text-sm text-muted-foreground">
              If you have a specific blank form that needs to be filled, upload it here
            </p>
          </div>

          {(personalDocs.length > 0 || formTemplate) && (
            <div className="space-y-3">
              {personalDocs.length > 0 && (
                <div className="space-y-2">
                  <Label>Personal Documents:</Label>
                  <div className="space-y-2">
                    {personalDocs.map((file, index) => (
                      <div key={index} className="flex items-center space-x-2 p-2 bg-muted rounded">
                        <FileText className="w-4 h-4 text-primary" />
                        <span className="text-sm">{file.name}</span>
                        <span className="text-xs text-muted-foreground">
                          ({(file.size / 1024 / 1024).toFixed(2)} MB)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {formTemplate && (
                <div className="space-y-2">
                  <Label>Form Template:</Label>
                  <div className="flex items-center space-x-2 p-2 bg-muted rounded">
                    <FileText className="w-4 h-4 text-amber-600" />
                    <span className="text-sm">{formTemplate.name}</span>
                    <span className="text-xs text-muted-foreground">
                      ({(formTemplate.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {uploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Processing...</span>
                <span className="text-sm text-muted-foreground">{progress}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          )}

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {result && result.success && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                {result.schemes_detected && (
                  <div className="mb-2">
                    <strong>Eligible Schemes Found:</strong> {result.schemes_detected.join(", ")}
                  </div>
                )}
                Forms filled successfully!
                {result.filled_forms &&
                  result.filled_forms.map((form: any, index: number) => (
                    <Button key={index} variant="link" className="p-0 ml-2 h-auto" asChild>
                      <a href={form.url} target="_blank" rel="noopener noreferrer">
                        <Download className="w-4 h-4 mr-1" />
                        Download {form.scheme_name} Form
                      </a>
                    </Button>
                  ))}
              </AlertDescription>
            </Alert>
          )}

          <Button onClick={handleUpload} disabled={personalDocs.length === 0 || uploading} className="w-full">
            {uploading ? (
              <>
                <Upload className="w-4 h-4 mr-2 animate-spin" />
                Processing Documents...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Process Documents & Fill Forms
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
