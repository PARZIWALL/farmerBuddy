"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Sprout, TrendingUp, Bell, Calendar, IndianRupee, Wheat, Droplets } from "lucide-react"

export default function FarmingRecommendations() {
  const [formData, setFormData] = useState({
    location: "",
    landSize: "",
    soilType: "",
    currentCrops: "",
    budget: "",
    experience: "",
    challenges: "",
  })

  const [recommendations, setRecommendations] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const generateRecommendations = async () => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setRecommendations({
        crops: [
          { name: "गेहूं", profit: "₹45,000/एकड़", season: "रबी", water: "मध्यम" },
          { name: "मक्का", profit: "₹38,000/एकड़", season: "खरीफ", water: "कम" },
          { name: "सरसों", profit: "₹32,000/एकड़", season: "रबी", water: "कम" },
        ],
        schemes: [
          { name: "PM-Kisan", amount: "₹6,000/वर्ष", deadline: "31 मार्च 2024" },
          { name: "Crop Insurance", amount: "प्रीमियम सब्सिडी", deadline: "15 अप्रैल 2024" },
        ],
      })
      setLoading(false)
    }, 2000)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">प्रोफाइल सेटअप</TabsTrigger>
          <TabsTrigger value="recommendations">सुझाव</TabsTrigger>
          <TabsTrigger value="schemes">योजनाएं</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Sprout className="w-5 h-5 text-primary" />
                <span>किसान प्रोफाइल</span>
              </CardTitle>
              <CardDescription>अपनी जानकारी दें ताकि हम आपको बेहतर सुझाव दे सकें</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="location">स्थान (जिला/राज्य)</Label>
                  <Input
                    id="location"
                    placeholder="जैसे: मेरठ, उत्तर प्रदेश"
                    value={formData.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="landSize">भूमि का आकार (एकड़ में)</Label>
                  <Input
                    id="landSize"
                    placeholder="जैसे: 5 एकड़"
                    value={formData.landSize}
                    onChange={(e) => handleInputChange("landSize", e.target.value)}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="soilType">मिट्टी का प्रकार</Label>
                  <Select value={formData.soilType} onValueChange={(value) => handleInputChange("soilType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="मिट्टी का प्रकार चुनें" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="clay">चिकनी मिट्टी</SelectItem>
                      <SelectItem value="sandy">रेतीली मिट्टी</SelectItem>
                      <SelectItem value="loamy">दोमट मिट्टी</SelectItem>
                      <SelectItem value="black">काली मिट्टी</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="budget">बजट (प्रति एकड़)</Label>
                  <Input
                    id="budget"
                    placeholder="जैसे: ₹25,000"
                    value={formData.budget}
                    onChange={(e) => handleInputChange("budget", e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="currentCrops">वर्तमान में उगाई जाने वाली फसलें</Label>
                <Input
                  id="currentCrops"
                  placeholder="जैसे: गेहूं, धान, गन्ना"
                  value={formData.currentCrops}
                  onChange={(e) => handleInputChange("currentCrops", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="experience">खेती का अनुभव</Label>
                <Select value={formData.experience} onValueChange={(value) => handleInputChange("experience", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="अनुभव चुनें" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">नया किसान (0-2 साल)</SelectItem>
                    <SelectItem value="intermediate">मध्यम अनुभव (3-10 साल)</SelectItem>
                    <SelectItem value="experienced">अनुभवी (10+ साल)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="challenges">मुख्य समस्याएं और चुनौतियां</Label>
                <Textarea
                  id="challenges"
                  placeholder="जैसे: पानी की कमी, कीट-पतंगे, बाजार की समस्या..."
                  value={formData.challenges}
                  onChange={(e) => handleInputChange("challenges", e.target.value)}
                  rows={4}
                />
              </div>

              <Button onClick={generateRecommendations} disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <TrendingUp className="w-4 h-4 mr-2 animate-spin" />
                    सुझाव तैयार कर रहे हैं...
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-4 h-4 mr-2" />
                    सुझाव प्राप्त करें
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          {recommendations ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Wheat className="w-5 h-5 text-primary" />
                    <span>फसल सुझाव</span>
                  </CardTitle>
                  <CardDescription>आपकी स्थिति के अनुसार बेहतरीन फसलें</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    {recommendations.crops.map((crop: any, index: number) => (
                      <Card key={index} className="border-2 hover:border-primary transition-colors">
                        <CardContent className="p-4">
                          <div className="text-center space-y-2">
                            <h3 className="font-semibold text-lg">{crop.name}</h3>
                            <div className="space-y-1">
                              <div className="flex items-center justify-center space-x-1">
                                <IndianRupee className="w-4 h-4 text-green-600" />
                                <span className="text-green-600 font-semibold">{crop.profit}</span>
                              </div>
                              <div className="flex items-center justify-center space-x-1">
                                <Calendar className="w-4 h-4 text-blue-600" />
                                <span className="text-sm">{crop.season}</span>
                              </div>
                              <div className="flex items-center justify-center space-x-1">
                                <Droplets className="w-4 h-4 text-blue-500" />
                                <span className="text-sm">{crop.water} पानी</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>विस्तृत विश्लेषण</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">मिट्टी और जलवायु विश्लेषण:</h4>
                    <p className="text-sm text-muted-foreground">
                      आपकी दोमट मिट्टी गेहूं और मक्का के लिए आदर्श है। वर्तमान मौसम की स्थिति रबी फसलों के लिए अनुकूल है।
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">बाजार की स्थिति:</h4>
                    <p className="text-sm text-muted-foreground">
                      गेहूं की कीमतें स्थिर हैं और अगले 6 महीनों में वृद्धि की संभावना है। मक्का की मांग बढ़ रही है।
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">सुझाव प्राप्त करने के लिए</h3>
                <p className="text-muted-foreground">पहले अपनी प्रोफाइल पूरी करें</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="schemes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-primary" />
                <span>उपलब्ध योजनाएं</span>
              </CardTitle>
              <CardDescription>आपके लिए उपयुक्त सरकारी योजनाएं</CardDescription>
            </CardHeader>
            <CardContent>
              {recommendations ? (
                <div className="space-y-4">
                  {recommendations.schemes.map((scheme: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <h4 className="font-semibold">{scheme.name}</h4>
                        <p className="text-sm text-muted-foreground">लाभ: {scheme.amount}</p>
                        <p className="text-sm text-red-600">अंतिम तिथि: {scheme.deadline}</p>
                      </div>
                      <div className="space-y-2">
                        <Badge variant="secondary">पात्र</Badge>
                        <Button size="sm" className="block">
                          आवेदन करें
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">योजनाओं की जानकारी के लिए पहले प्रोफाइल पूरी करें</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
