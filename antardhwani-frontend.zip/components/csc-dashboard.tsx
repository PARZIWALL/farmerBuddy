"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, Users, FileText, TrendingUp, Plus, Upload } from "lucide-react"

interface QueueItem {
  id: string
  name: string
  scheme: string
  status: "waiting" | "processing" | "completed"
  time: string
  documents: number
}

export default function CSCDashboard() {
  const [queue, setQueue] = useState<QueueItem[]>([
    { id: "1", name: "राम कुमार", scheme: "PM-Kisan", status: "processing", time: "10:30 AM", documents: 3 },
    { id: "2", name: "सीता देवी", scheme: "KCC", status: "waiting", time: "11:00 AM", documents: 4 },
    { id: "3", name: "मोहन सिंह", scheme: "RIDF", status: "waiting", time: "11:30 AM", documents: 2 },
    { id: "4", name: "गीता शर्मा", scheme: "PM-Kisan", status: "completed", time: "10:00 AM", documents: 3 },
  ])

  const [stats] = useState({
    todayForms: 12,
    avgTime: "8 min",
    queueLength: 3,
    completionRate: 95,
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "waiting":
        return "bg-yellow-100 text-yellow-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "waiting":
        return "प्रतीक्षा में"
      case "processing":
        return "प्रक्रिया में"
      case "completed":
        return "पूर्ण"
      default:
        return status
    }
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.todayForms}</p>
                <p className="text-sm text-muted-foreground">आज के फॉर्म</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-secondary" />
              <div>
                <p className="text-2xl font-bold">{stats.avgTime}</p>
                <p className="text-sm text-muted-foreground">औसत समय</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-accent" />
              <div>
                <p className="text-2xl font-bold">{stats.queueLength}</p>
                <p className="text-sm text-muted-foreground">कतार में</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.completionRate}%</p>
                <p className="text-sm text-muted-foreground">सफलता दर</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="queue" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="queue">कतार प्रबंधन</TabsTrigger>
          <TabsTrigger value="schedule">अपॉइंटमेंट</TabsTrigger>
          <TabsTrigger value="bulk">बल्क प्रोसेसिंग</TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>आज की कतार</CardTitle>
                  <CardDescription>वर्तमान में प्रतीक्षा कर रहे किसान</CardDescription>
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  नया जोड़ें
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {queue.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Users className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{item.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {item.scheme} • {item.documents} दस्तावेज
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="text-sm text-muted-foreground">{item.time}</span>
                      <Badge className={getStatusColor(item.status)}>{getStatusText(item.status)}</Badge>
                      <Button variant="outline" size="sm">
                        प्रक्रिया शुरू करें
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>अपॉइंटमेंट शेड्यूलिंग</CardTitle>
              <CardDescription>किसानों के लिए समय निर्धारित करें</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="farmer-name">किसान का नाम</Label>
                    <Input id="farmer-name" placeholder="नाम दर्ज करें" />
                  </div>
                  <div>
                    <Label htmlFor="phone">फोन नंबर</Label>
                    <Input id="phone" placeholder="फोन नंबर दर्ज करें" />
                  </div>
                  <div>
                    <Label htmlFor="scheme">योजना</Label>
                    <Input id="scheme" placeholder="योजना का नाम" />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="date">दिनांक</Label>
                    <Input id="date" type="date" />
                  </div>
                  <div>
                    <Label htmlFor="time">समय</Label>
                    <Input id="time" type="time" />
                  </div>
                  <Button className="w-full">
                    <Calendar className="w-4 h-4 mr-2" />
                    अपॉइंटमेंट बुक करें
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>बल्क प्रोसेसिंग</CardTitle>
              <CardDescription>एक साथ कई फॉर्म प्रोसेस करें</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">बल्क डॉक्यूमेंट अपलोड करें</h3>
                <p className="text-muted-foreground mb-4">एक ZIP फाइल में कई किसानों के दस्तावेज अपलोड करें</p>
                <Button>फाइल चुनें</Button>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-2">प्रोसेसिंग स्टेटस</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>कुल फाइलें</span>
                        <span>0</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>प्रोसेस्ड</span>
                        <span>0</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>बाकी</span>
                        <span>0</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-2">अनुमानित समय</h4>
                    <p className="text-2xl font-bold text-primary">--</p>
                    <p className="text-sm text-muted-foreground">मिनट</p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
