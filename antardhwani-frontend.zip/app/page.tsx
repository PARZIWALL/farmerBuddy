"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Users, TrendingUp, Upload, Clock, CheckCircle, Wheat, Sprout } from "lucide-react"
import DocumentUpload from "@/components/document-upload"
import CSCDashboard from "@/components/csc-dashboard"
import FarmingRecommendations from "@/components/farming-recommendations"

export default function HomePage() {
  const [activeService, setActiveService] = useState<string>("upload")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-12 h-12 bg-primary rounded-lg">
                <Wheat className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground font-work-sans">Antardhwani</h1>
                <p className="text-sm text-muted-foreground">Digital Form Assistant for Farmers</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
              Government Approved
            </Badge>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-card to-background py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-foreground mb-4 font-work-sans">
            Fill Government Forms in Minutes, Not Hours
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Upload your documents and let our AI extract information to fill government scheme forms automatically.
            Perfect for farmers and CSC operators.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <div className="flex items-center space-x-2 bg-background px-4 py-2 rounded-lg border">
              <CheckCircle className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">AI-Powered</span>
            </div>
            <div className="flex items-center space-x-2 bg-background px-4 py-2 rounded-lg border">
              <CheckCircle className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">Secure & Private</span>
            </div>
            <div className="flex items-center space-x-2 bg-background px-4 py-2 rounded-lg border">
              <CheckCircle className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium">Government Schemes</span>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4 font-work-sans">Our Services</h3>
            <p className="text-lg text-muted-foreground">Choose the service that best fits your needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="cursor-pointer transition-all hover:shadow-lg border-2 hover:border-primary">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="font-work-sans">Individual Form Filling</CardTitle>
                <CardDescription>
                  Upload your documents and get forms filled instantly for physical submission
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>Upload PDF documents</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>AI extracts information</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>Download filled forms</span>
                  </li>
                </ul>
                <Button
                  className="w-full"
                  onClick={() => setActiveService("upload")}
                  variant={activeService === "upload" ? "default" : "outline"}
                >
                  Start Form Filling
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all hover:shadow-lg border-2 hover:border-primary">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-secondary" />
                </div>
                <CardTitle className="font-work-sans">CSC Dashboard</CardTitle>
                <CardDescription>Help CSC operators fill forms faster and manage queues efficiently</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                  <li className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-secondary" />
                    <span>Queue management</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-secondary" />
                    <span>Bulk form processing</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-secondary" />
                    <span>Appointment scheduling</span>
                  </li>
                </ul>
                <Button
                  className="w-full"
                  variant={activeService === "csc" ? "default" : "outline"}
                  onClick={() => setActiveService("csc")}
                >
                  Access CSC Dashboard
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer transition-all hover:shadow-lg border-2 hover:border-primary">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-accent" />
                </div>
                <CardTitle className="font-work-sans">Farming Recommendations</CardTitle>
                <CardDescription>
                  Get personalized farming advice and scheme notifications based on your profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                  <li className="flex items-center space-x-2">
                    <Sprout className="w-4 h-4 text-accent" />
                    <span>Crop recommendations</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Sprout className="w-4 h-4 text-accent" />
                    <span>Scheme notifications</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Sprout className="w-4 h-4 text-accent" />
                    <span>Profit analysis</span>
                  </li>
                </ul>
                <Button
                  className="w-full"
                  variant={activeService === "recommendations" ? "default" : "outline"}
                  onClick={() => setActiveService("recommendations")}
                >
                  Get Recommendations
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Service Content */}
          <div className="max-w-4xl mx-auto">
            <Tabs value={activeService} onValueChange={setActiveService}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="upload" className="flex items-center space-x-2">
                  <Upload className="w-4 h-4" />
                  <span>Form Filling</span>
                </TabsTrigger>
                <TabsTrigger value="csc" className="flex items-center space-x-2">
                  <Users className="w-4 h-4" />
                  <span>CSC Dashboard</span>
                </TabsTrigger>
                <TabsTrigger value="recommendations" className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4" />
                  <span>Recommendations</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="mt-8">
                <DocumentUpload />
              </TabsContent>

              <TabsContent value="csc" className="mt-8">
                <CSCDashboard />
              </TabsContent>

              <TabsContent value="recommendations" className="mt-8">
                <FarmingRecommendations />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Wheat className="w-5 h-5 text-primary" />
            <span className="font-semibold text-foreground">Antardhwani</span>
          </div>
          <p className="text-sm text-muted-foreground">Empowering farmers with digital tools for government schemes</p>
        </div>
      </footer>
    </div>
  )
}
